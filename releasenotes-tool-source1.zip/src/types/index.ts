// Azure DevOps types
export interface AzureDevOpsConfig {
  organization: string;
  project: string;
  repository: string;
  personalAccessToken: string;
}

export interface Commit {
  commitId: string;
  comment: string;
  author: {
    name: string;
    email: string;
  };
  committer: {
    name: string;
    email: string;
  };
  url: string;
}

export interface PullRequest {
  id: string;
  title: string;
  author: string;
  url: string;
  mergedAt: string;
  description?: string;
}

export interface Tag {
  name: string;
  objectId: string;
  url: string;
  createdBy: {
    displayName: string;
    uniqueName: string;
  };
  creationDate: string;
}

// Jira types
export interface JiraConfig {
  baseUrl: string;
  username: string;
  apiToken: string;
  projectKey: string;
}

export interface JiraTicket {
  id: string;
  key: string;
  summary: string;
  description: string;
  status: string;
  assignee?: string;
  reporter: string;
  created: string;
  updated: string;
  url: string;
}

// Configuration types
export interface AppConfig {
  azureOrg: string;
  azureProject: string;
  azureRepo: string;
  azurePat: string;
  jiraBaseUrl: string;
  jiraPat: string;
}

// Form data types
export interface ReleaseFormData {
  commitId: string;
  previousTag: string;
  newTag: string;
  repository: string;
}

// Step types
export type ReleaseStep = 'input' | 'processing' | 'pr-selection' | 'final-processing' | 'result';

export interface ReleaseData {
  // Step 1: User input
  commitHash: string;
  previousTag: string;
  newTag: string;

  // Step 2-5: Auto-generated data
  jiraTicketId?: string;
  jiraTicketUrl?: string;
  gitTagCreated?: boolean;
  pullRequests?: PullRequest[];

  // Step 6: User selection
  selectedPRs?: string[]; // Array of PR IDs

  // Step 7-8: Final result
  finalText?: string;
  jiraTicketUpdated?: boolean;
}

export interface InputFormProps {
  onComplete: (data: Partial<ReleaseData>) => void;
  releaseData: ReleaseData | null;
}

export interface PRSelectorProps {
  onComplete: (selectedPRs: string[]) => void;
  onBack: () => void;
  releaseData: ReleaseData | null;
}

export interface ResultDisplayProps {
  releaseData: ReleaseData | null;
  onBack: () => void;
  onRestart: () => void;
}

export interface StepIndicatorProps {
  currentStep: ReleaseStep;
}

// API response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}
