import { useMutation, useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { mockApi } from '../services/mockApi';
import { PullRequest, ReleaseData } from '../types';

// Step status types
export type StepStatus = 'idle' | 'loading' | 'success' | 'error';

export interface StepState {
  status: StepStatus;
  error?: string;
  data?: any;
}

export interface ReleaseProcessState {
  createJiraTicket: StepState;
  updateJiraTicket: StepState;
  createGitTag: StepState;
  fetchPullRequests: StepState;
  updateTicketWithPRs: StepState;
  generateReleaseNotes: StepState;
}

// Use the mock API - replace this with real API calls
const api = mockApi;

// React Query hooks
export const useCreateJiraTicket = () => {
  return useMutation({
    mutationFn: (releaseData: ReleaseData) => api.createJiraTicket(releaseData),
    retry: 2,
    retryDelay: 1000,
  });
};

export const useUpdateJiraTicket = () => {
  return useMutation({
    mutationFn: ({ ticketKey, releaseData }: { ticketKey: string; releaseData: ReleaseData }) =>
      api.updateJiraTicket(ticketKey, releaseData),
    retry: 2,
    retryDelay: 1000,
  });
};

export const useCreateGitTag = () => {
  return useMutation({
    mutationFn: ({ tagName, commitHash }: { tagName: string; commitHash: string }) =>
      api.createGitTag(tagName, commitHash),
    retry: 2,
    retryDelay: 1000,
  });
};

export const useFetchPullRequests = (fromTag: string, toTag: string, enabled: boolean = false) => {
  return useQuery({
    queryKey: ['pullRequests', fromTag, toTag],
    queryFn: () => api.fetchPullRequests(fromTag, toTag),
    enabled: enabled && !!fromTag && !!toTag,
    retry: 2,
    retryDelay: 1000,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

export const useUpdateTicketWithPRs = () => {
  return useMutation({
    mutationFn: ({
      ticketKey,
      selectedPRs,
      allPRs,
    }: {
      ticketKey: string;
      selectedPRs: string[];
      allPRs: PullRequest[];
    }) => api.updateTicketWithPRs(ticketKey, selectedPRs, allPRs),
    retry: 2,
    retryDelay: 1000,
  });
};

export const useGenerateReleaseNotes = () => {
  return useMutation({
    mutationFn: (releaseData: ReleaseData) => api.generateReleaseNotes(releaseData),
    retry: 1,
    retryDelay: 500,
  });
};

// Main release process hook
export const useReleaseProcess = () => {
  const [stepStates, setStepStates] = useState<ReleaseProcessState>({
    createJiraTicket: { status: 'idle' },
    updateJiraTicket: { status: 'idle' },
    createGitTag: { status: 'idle' },
    fetchPullRequests: { status: 'idle' },
    updateTicketWithPRs: { status: 'idle' },
    generateReleaseNotes: { status: 'idle' },
  });

  const [currentTicketKey, setCurrentTicketKey] = useState<string>('');

  // Mutations
  const createJiraTicketMutation = useCreateJiraTicket();
  const updateJiraTicketMutation = useUpdateJiraTicket();
  const createGitTagMutation = useCreateGitTag();
  const updateTicketWithPRsMutation = useUpdateTicketWithPRs();
  const generateReleaseNotesMutation = useGenerateReleaseNotes();

  // Update step state helper
  const updateStepState = (step: keyof ReleaseProcessState, state: Partial<StepState>) => {
    setStepStates(prev => ({
      ...prev,
      [step]: { ...prev[step], ...state },
    }));
  };

  // Step 2: Create Jira ticket
  const createJiraTicket = async (releaseData: ReleaseData) => {
    updateStepState('createJiraTicket', { status: 'loading' });

    try {
      const result = await createJiraTicketMutation.mutateAsync(releaseData);
      // React Query mutation returns the API response directly
      if (result.success && result.data) {
        setCurrentTicketKey(result.data.key);
        updateStepState('createJiraTicket', {
          status: 'success',
          data: result.data,
        });
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to create Jira ticket');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateStepState('createJiraTicket', {
        status: 'error',
        error: errorMessage,
      });
      throw error;
    }
  };

  // Step 3: Update Jira ticket
  const updateJiraTicket = async (releaseData: ReleaseData) => {
    // Try to get the ticket key from multiple sources
    const createTicketState = stepStates.createJiraTicket;
    let ticketKey = '';

    // First try to get from the createJiraTicket state
    if (createTicketState.status === 'success' && createTicketState.data) {
      ticketKey = createTicketState.data.key;
    }
    // If not available, try to get from currentTicketKey (set during creation)
    else if (currentTicketKey) {
      ticketKey = currentTicketKey;
    }
    // If not available, try to get from releaseData (if it was set)
    else if (releaseData.jiraTicketId) {
      ticketKey = releaseData.jiraTicketId;
    }

    if (ticketKey) {
      updateStepState('updateJiraTicket', { status: 'loading' });

      try {
        const result = await updateJiraTicketMutation.mutateAsync({
          ticketKey: ticketKey,
          releaseData,
        });

        if (result.success && result.data) {
          updateStepState('updateJiraTicket', {
            status: 'success',
            data: result.data,
          });
          return result.data;
        } else {
          throw new Error(result.error || 'Failed to update Jira ticket');
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
        updateStepState('updateJiraTicket', {
          status: 'error',
          error: errorMessage,
        });
        throw error;
      }
    } else {
      // If no ticket key is available, mark updateJiraTicket as error
      updateStepState('updateJiraTicket', {
        status: 'error',
        error: 'Cannot update ticket: No ticket key available. Please create Jira ticket first.',
      });
      throw new Error('Cannot update ticket: No ticket key available. Please create Jira ticket first.');
    }
  };

  // Step 4: Create Git tag
  const createGitTag = async (tagName: string, commitHash: string) => {
    updateStepState('createGitTag', { status: 'loading' });

    try {
      const result = await createGitTagMutation.mutateAsync({ tagName, commitHash });

      if (result.success && result.data) {
        updateStepState('createGitTag', {
          status: 'success',
          data: result.data,
        });
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to create Git tag');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateStepState('createGitTag', {
        status: 'error',
        error: errorMessage,
      });
      throw error;
    }
  };

  // Step 5: Fetch pull requests
  const fetchPullRequests = async (fromTag: string, toTag: string) => {
    updateStepState('fetchPullRequests', { status: 'loading' });

    try {
      const result = await api.fetchPullRequests(fromTag, toTag);

      if (result.success && result.data) {
        updateStepState('fetchPullRequests', {
          status: 'success',
          data: result.data,
        });
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to fetch pull requests');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateStepState('fetchPullRequests', {
        status: 'error',
        error: errorMessage,
      });
      throw error;
    }
  };

  // Step 7: Update ticket with selected PRs
  const updateTicketWithPRs = async (selectedPRs: string[], allPRs: PullRequest[]) => {
    if (!currentTicketKey) {
      throw new Error('No ticket key available');
    }

    updateStepState('updateTicketWithPRs', { status: 'loading' });

    try {
      const result = await updateTicketWithPRsMutation.mutateAsync({
        ticketKey: currentTicketKey,
        selectedPRs,
        allPRs,
      });

      if (result.success && result.data) {
        updateStepState('updateTicketWithPRs', {
          status: 'success',
          data: result.data,
        });
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to update ticket with PRs');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateStepState('updateTicketWithPRs', {
        status: 'error',
        error: errorMessage,
      });
      throw error;
    }
  };

  // Step 8: Generate release notes
  const generateReleaseNotes = async (releaseData: ReleaseData) => {
    updateStepState('generateReleaseNotes', { status: 'loading' });

    try {
      const result = await generateReleaseNotesMutation.mutateAsync(releaseData);

      if (result.success && result.data) {
        updateStepState('generateReleaseNotes', {
          status: 'success',
          data: result.data,
        });
        return result.data;
      } else {
        throw new Error(result.error || 'Failed to generate release notes');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      updateStepState('generateReleaseNotes', {
        status: 'error',
        error: errorMessage,
      });
      throw error;
    }
  };

  // Reset all states
  const resetStates = () => {
    setStepStates({
      createJiraTicket: { status: 'idle' },
      updateJiraTicket: { status: 'idle' },
      createGitTag: { status: 'idle' },
      fetchPullRequests: { status: 'idle' },
      updateTicketWithPRs: { status: 'idle' },
      generateReleaseNotes: { status: 'idle' },
    });
    setCurrentTicketKey('');
  };

  return {
    stepStates,
    currentTicketKey,
    createJiraTicket,
    updateJiraTicket,
    createGitTag,
    fetchPullRequests,
    updateTicketWithPRs,
    generateReleaseNotes,
    resetStates,
    isLoading: Object.values(stepStates).some(state => state.status === 'loading'),
    hasErrors: Object.values(stepStates).some(state => state.status === 'error'),
  };
};
