# Release Notes Tool

一个用于自动化创建release notes的React应用，集成了Azure DevOps和Jira。

## 功能特性

- 🚀 自动化创建Jira工单
- 🏷️ 自动创建Git标签
- 📋 获取并选择Pull Requests
- 📝 生成Release Notes
- 🎯 步骤化流程指示器
- 📱 响应式设计

## 技术栈

- **React 18** - 用户界面框架
- **TypeScript** - 类型安全
- **TanStack Query** - 数据获取和缓存
- **React Hook Form** - 表单管理
- **Zod** - 数据验证
- **Tailwind CSS** - 样式框架
- **Lucide React** - 图标库

## 安装和运行

### 1. 克隆项目

```bash
git clone <repository-url>
cd releasenotes-tool
```

### 2. 安装依赖

```bash
npm install
```

### 3. 配置环境变量

复制 `env.example` 文件为 `.env.local` 并填写你的配置：

```bash
cp env.example .env.local
```

编辑 `.env.local` 文件，填入你的Azure DevOps和Jira配置：

```env
# Azure DevOps Configuration
REACT_APP_AZURE_ORG=your-organization
REACT_APP_AZURE_PROJECT=your-project
REACT_APP_AZURE_REPO=your-repository
REACT_APP_AZURE_PAT=your-personal-access-token

# Jira Configuration
REACT_APP_JIRA_BASE_URL=https://your-domain.atlassian.net
REACT_APP_JIRA_USERNAME=your-email@example.com
REACT_APP_JIRA_API_TOKEN=your-api-token
REACT_APP_JIRA_PROJECT_KEY=PROJ
```

### 4. 启动开发服务器

```bash
npm start
```

应用将在 [http://localhost:3000](http://localhost:3000) 启动。

## 使用流程

1. **输入信息** - 输入commit ID、上一次release tag和新tag
2. **创建Jira工单** - 系统自动创建Jira工单
3. **更新工单信息** - 系统更新工单的初始信息
4. **创建Git标签** - 系统在Azure DevOps中创建新的Git标签
5. **获取PR列表** - 系统获取两个标签之间的所有Pull Requests
6. **选择PR** - 用户可以选择需要的Pull Requests
7. **更新工单** - 系统用选中的PR信息更新Jira工单
8. **显示结果** - 显示生成的Release Notes供复制

## 项目结构

```
src/
├── components/          # React组件
│   ├── StepIndicator.tsx
│   ├── InputForm.tsx
│   ├── PRSelector.tsx
│   └── ResultDisplay.tsx
├── hooks/              # 自定义React Hooks
│   └── useReleaseProcess.ts
├── services/           # API服务
│   └── api.ts
├── types/              # TypeScript类型定义
│   └── index.ts
├── utils/              # 工具函数
│   └── cn.ts
└── App.tsx            # 主应用组件
```

## 开发

### 代码格式化

项目使用Prettier进行代码格式化：

```bash
npm run format
```

### 代码检查

项目使用ESLint进行代码检查：

```bash
npm run lint
```

### 构建生产版本

```bash
npm run build
```

## 配置说明

### Azure DevOps配置

1. 在Azure DevOps中创建Personal Access Token (PAT)
2. 确保PAT有足够的权限访问仓库和创建标签
3. 配置组织、项目、仓库名称

### Jira配置

1. 在Jira中创建API Token
2. 确保用户有权限在指定项目中创建和更新工单
3. 配置Jira域名、用户名、API Token和项目Key

## 贡献

1. Fork项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开Pull Request

## 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。
