import {
  Close as CloseIcon,
  Refresh as RefreshIcon,
  Save as SaveIcon,
  Warning as WarningIcon,
} from '@mui/icons-material';
import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  TextField,
  Typography,
} from '@mui/material';
import React, { useEffect, useState } from 'react';
import { AppConfig } from '../types';
import { defaultConfig, loadConfig, resetConfig, saveConfig } from '../utils/config';

interface ConfigDialogProps {
  open: boolean;
  onClose: () => void;
  onConfigUpdate?: () => void;
}

export const ConfigDialog: React.FC<ConfigDialogProps> = ({ open, onClose, onConfigUpdate }) => {
  const [config, setConfig] = useState<AppConfig>(defaultConfig);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // Load config when dialog opens
  useEffect(() => {
    if (open) {
      const loadedConfig = loadConfig();
      setConfig(loadedConfig);
      setShowSuccess(false);
    }
  }, [open]);

  const handleInputChange = (field: keyof AppConfig) => (event: React.ChangeEvent<HTMLInputElement>) => {
    setConfig(prev => ({
      ...prev,
      [field]: event.target.value,
    }));
  };

  const handleSave = () => {
    saveConfig(config);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    onConfigUpdate?.();
  };

  const handleReset = () => {
    setConfig(defaultConfig);
    resetConfig();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    setShowResetConfirm(false);
    onConfigUpdate?.();
  };

  const handleClose = () => {
    onClose();
  };

  return (
    <>
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="md"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
          },
        }}
      >
        <DialogTitle sx={{ m: 0, p: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          Configuration Settings
          <IconButton
            aria-label="close"
            onClick={handleClose}
            sx={{
              color: theme => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>

        <DialogContent dividers>
          {showSuccess && (
            <Alert severity="success" sx={{ mb: 2 }}>
              Configuration saved successfully!
            </Alert>
          )}

          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Azure DevOps Configuration
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
              <TextField
                label="Organization"
                value={config.azureOrg}
                onChange={handleInputChange('azureOrg')}
                fullWidth
                size="small"
                helperText="Azure DevOps organization name"
              />
              <TextField
                label="Project"
                value={config.azureProject}
                onChange={handleInputChange('azureProject')}
                fullWidth
                size="small"
                helperText="Azure DevOps project name"
              />
              <TextField
                label="Repository"
                value={config.azureRepo}
                onChange={handleInputChange('azureRepo')}
                fullWidth
                size="small"
                helperText="Repository name"
              />
              <TextField
                label="Personal Access Token"
                value={config.azurePat}
                onChange={handleInputChange('azurePat')}
                fullWidth
                size="small"
                type="password"
                helperText="Azure DevOps PAT (stored locally)"
              />
            </Box>
          </Box>

          <Divider sx={{ my: 3 }} />

          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" gutterBottom color="primary">
              Jira Configuration
            </Typography>
            <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2 }}>
              <TextField
                label="Base URL"
                value={config.jiraBaseUrl}
                onChange={handleInputChange('jiraBaseUrl')}
                fullWidth
                size="small"
                helperText="Jira instance URL"
              />
              <TextField
                label="Personal Access Token"
                value={config.jiraPat}
                onChange={handleInputChange('jiraPat')}
                fullWidth
                size="small"
                type="password"
                helperText="Jira PAT (stored locally)"
              />
            </Box>
          </Box>

          <Alert severity="info" sx={{ mt: 2 }}>
            <Typography variant="body2">
              All configuration is stored locally in your browser. Your Personal Access Tokens are never sent to
              external servers.
            </Typography>
          </Alert>
        </DialogContent>

        <DialogActions sx={{ p: 2, gap: 1 }}>
          <Button
            onClick={() => setShowResetConfirm(true)}
            startIcon={<RefreshIcon />}
            variant="outlined"
            color="secondary"
          >
            Reset to Defaults
          </Button>
          <Box sx={{ flexGrow: 1 }} />
          <Button onClick={handleClose} variant="outlined">
            Cancel
          </Button>
          <Button onClick={handleSave} startIcon={<SaveIcon />} variant="contained" color="primary">
            Save Configuration
          </Button>
        </DialogActions>
      </Dialog>

      {/* Reset Confirmation Dialog */}
      <Dialog
        open={showResetConfirm}
        onClose={() => setShowResetConfirm(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 2,
          },
        }}
      >
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <WarningIcon color="warning" />
          Confirm Reset
        </DialogTitle>
        <DialogContent>
          <Typography variant="body1" sx={{ mb: 2 }}>
            Are you sure you want to reset all configuration to default values?
          </Typography>
          <Typography variant="body2" color="text.secondary">
            This action will:
          </Typography>
          <Box component="ul" sx={{ mt: 1, mb: 2, pl: 2 }}>
            <Typography component="li" variant="body2" color="text.secondary">
              Clear all saved configuration
            </Typography>
            <Typography component="li" variant="body2" color="text.secondary">
              Reset to default values
            </Typography>
            <Typography component="li" variant="body2" color="text.secondary">
              Remove any stored Personal Access Tokens
            </Typography>
          </Box>
          <Typography variant="body2" color="error" sx={{ fontWeight: 500 }}>
            This action cannot be undone.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2, gap: 1 }}>
          <Button onClick={() => setShowResetConfirm(false)} variant="outlined">
            Cancel
          </Button>
          <Button onClick={handleReset} variant="contained" color="error" startIcon={<RefreshIcon />}>
            Reset to Defaults
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};
