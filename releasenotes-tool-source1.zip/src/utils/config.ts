import { AppConfig } from '../types';

const CONFIG_STORAGE_KEY = 'hsbc-release-notes-config';

// Default configuration
export const defaultConfig: AppConfig = {
  azureOrg: 'hsbccst',
  azureProject: 'WholesaleOpenAI',
  azureRepo: 'ps-dev',
  azurePat: '',
  jiraBaseUrl: 'https://alm-jira.systems.uk.hsbc/jira',
  jiraPat: '',
};

// Load configuration from localStorage
export const loadConfig = (): AppConfig => {
  try {
    const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Merge with defaults to ensure all fields exist
      return { ...defaultConfig, ...parsed };
    }
  } catch (error) {
    console.error('Failed to load config from localStorage:', error);
  }
  return defaultConfig;
};

// Save configuration to localStorage
export const saveConfig = (config: AppConfig): void => {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (error) {
    console.error('Failed to save config to localStorage:', error);
  }
};

// Reset configuration to defaults
export const resetConfig = (): void => {
  try {
    localStorage.removeItem(CONFIG_STORAGE_KEY);
  } catch (error) {
    console.error('Failed to reset config:', error);
  }
};
