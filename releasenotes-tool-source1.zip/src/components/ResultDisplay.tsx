import { ArrowBack, ContentCopy, Refresh } from '@mui/icons-material';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  IconButton,
  Paper,
  Snackbar,
  Typography,
} from '@mui/material';
import { useState } from 'react';
import { ResultDisplayProps } from '../types';

export function ResultDisplay({ releaseData, onBack, onRestart }: ResultDisplayProps) {
  const [showCopySuccess, setShowCopySuccess] = useState(false);

  // Mock final text - replace with actual generated text
  const mockFinalText = `# Release Notes - ${releaseData?.newTag}

## Overview
This release includes ${releaseData?.selectedPRs?.length || 0} pull requests with various improvements and bug fixes.

## Changes

### New Features
- **Add new authentication feature** - Implemented OAuth2 authentication flow
  - Author: John Doe
  - PR: [#1](https://dev.azure.com/project/pullrequest/1)

### Bug Fixes
- **Fix login page styling issues** - Resolved CSS conflicts and improved responsive design
  - Author: Jane Smith
  - PR: [#2](https://dev.azure.com/project/pullrequest/2)

### Documentation
- **Update API documentation** - Added comprehensive API documentation for new endpoints
  - Author: Mike Johnson
  - PR: [#3](https://dev.azure.com/project/pullrequest/3)

## Technical Details
- **Previous Tag:** ${releaseData?.previousTag}
- **New Tag:** ${releaseData?.newTag}
- **Commit Hash:** ${releaseData?.commitHash}
- **Jira Ticket:** [${releaseData?.jiraTicketId || 'TICKET-123'}](https://jira.company.com/browse/${releaseData?.jiraTicketId || 'TICKET-123'})

## Deployment Notes
Please ensure all database migrations are applied before deploying this release.`;

  const finalText = releaseData?.finalText || mockFinalText;

  const handleCopyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(finalText);
      setShowCopySuccess(true);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  const handleCloseSnackbar = () => {
    setShowCopySuccess(false);
  };

  return (
    <Card elevation={2}>
      <CardContent sx={{ p: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Button startIcon={<ArrowBack />} onClick={onBack} sx={{ mr: 2 }}>
            Back
          </Button>
          <Typography variant="h5">Release Notes Generated</Typography>
        </Box>

        <Alert severity="success" sx={{ mb: 3 }}>
          <Typography variant="body2">
            <strong>Success!</strong> The Jira ticket has been updated and release notes have been generated.
          </Typography>
        </Alert>

        <Box sx={{ mb: 3 }}>
          <Typography variant="h6" gutterBottom>
            Release Summary
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
            <Chip label={`Previous: ${releaseData?.previousTag}`} variant="outlined" />
            <Chip label={`New: ${releaseData?.newTag}`} color="primary" />
            <Chip label={`${releaseData?.selectedPRs?.length || 0} PRs selected`} variant="outlined" />
            {releaseData?.jiraTicketId && (
              <Chip
                label={`Jira: ${releaseData.jiraTicketId}`}
                color="secondary"
                variant="outlined"
                component="a"
                href={`https://jira.company.com/browse/${releaseData.jiraTicketId}`}
                target="_blank"
                clickable
              />
            )}
          </Box>
        </Box>

        <Divider sx={{ mb: 3 }} />

        <Box sx={{ mb: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h6">Generated Release Notes</Typography>
            <IconButton onClick={handleCopyToClipboard} color="primary" title="Copy to clipboard">
              <ContentCopy />
            </IconButton>
          </Box>

          <Paper
            elevation={1}
            sx={{
              p: 3,
              backgroundColor: 'grey.50',
              border: 1,
              borderColor: 'grey.300',
              maxHeight: 500,
              overflow: 'auto',
              fontFamily: 'monospace',
              fontSize: '0.875rem',
              lineHeight: 1.6,
              whiteSpace: 'pre-wrap',
            }}
          >
            {finalText}
          </Paper>
        </Box>

        <Alert severity="info" sx={{ mb: 3 }}>
          <Typography variant="body2">
            <strong>Next steps:</strong> Copy the release notes above and paste them into your release documentation,
            team communication channels, or wherever you need to share the release information.
          </Typography>
        </Alert>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Button variant="outlined" startIcon={<Refresh />} onClick={onRestart}>
            Start New Release
          </Button>

          <Button variant="contained" startIcon={<ContentCopy />} onClick={handleCopyToClipboard}>
            Copy Release Notes
          </Button>
        </Box>

        <Snackbar
          open={showCopySuccess}
          autoHideDuration={3000}
          onClose={handleCloseSnackbar}
          message="Release notes copied to clipboard!"
        />
      </CardContent>
    </Card>
  );
}
