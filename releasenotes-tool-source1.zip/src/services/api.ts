import axios from 'axios';
import type { ApiResponse, AzureDevOpsConfig, Commit, JiraConfig, JiraTicket, PullRequest, Tag } from '../types';

// Azure DevOps API service
export class AzureDevOpsService {
  private config: AzureDevOpsConfig;
  private baseUrl: string;

  constructor(config: AzureDevOpsConfig) {
    this.config = config;
    this.baseUrl = `https://dev.azure.com/${config.organization}/${config.project}/_apis`;
  }

  private getHeaders() {
    return {
      Authorization: `Basic ${btoa(`:${this.config.personalAccessToken}`)}`,
      'Content-Type': 'application/json',
    };
  }

  async getCommit(commitId: string): Promise<ApiResponse<Commit>> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/git/repositories/${this.config.repository}/commits/${commitId}`,
        { headers: this.getHeaders() }
      );
      return { success: true, data: response.data };
    } catch (error) {
      return { success: false, error: 'Failed to fetch commit' };
    }
  }

  async createTag(tagName: string, commitId: string): Promise<ApiResponse<Tag>> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/git/repositories/${this.config.repository}/annotatedtags`,
        {
          name: tagName,
          taggedObject: {
            objectId: commitId,
          },
          message: `Release ${tagName}`,
        },
        { headers: this.getHeaders() }
      );
      return { success: true, data: response.data };
    } catch (error) {
      return { success: false, error: 'Failed to create tag' };
    }
  }

  async getPullRequests(fromTag: string, toTag: string): Promise<ApiResponse<PullRequest[]>> {
    try {
      const response = await axios.get(`${this.baseUrl}/git/repositories/${this.config.repository}/pullrequests`, {
        headers: this.getHeaders(),
        params: {
          'searchCriteria.status': 'completed',
          'searchCriteria.targetRefName': 'refs/heads/main',
          $top: 1000,
        },
      });

      // Filter PRs between the two tags
      const prs = response.data.value.filter((pr: any) => {
        // This is a simplified filter - you might need to implement more complex logic
        // based on your specific requirements
        return pr.status === 'completed';
      });

      return { success: true, data: prs };
    } catch (error) {
      return { success: false, error: 'Failed to fetch pull requests' };
    }
  }
}

// Jira API service
export class JiraService {
  private config: JiraConfig;
  private baseUrl: string;

  constructor(config: JiraConfig) {
    this.config = config;
    this.baseUrl = `${config.baseUrl}/rest/api/3`;
  }

  private getHeaders() {
    return {
      Authorization: `Basic ${btoa(`${this.config.username}:${this.config.apiToken}`)}`,
      'Content-Type': 'application/json',
    };
  }

  async createTicket(summary: string, description: string): Promise<ApiResponse<JiraTicket>> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/issue`,
        {
          fields: {
            project: {
              key: this.config.projectKey,
            },
            summary: summary,
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: description,
                    },
                  ],
                },
              ],
            },
            issuetype: {
              name: 'Task',
            },
          },
        },
        { headers: this.getHeaders() }
      );

      return { success: true, data: response.data };
    } catch (error) {
      return { success: false, error: 'Failed to create Jira ticket' };
    }
  }

  async updateTicket(ticketKey: string, description: string): Promise<ApiResponse<JiraTicket>> {
    try {
      const response = await axios.put(
        `${this.baseUrl}/issue/${ticketKey}`,
        {
          fields: {
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: description,
                    },
                  ],
                },
              ],
            },
          },
        },
        { headers: this.getHeaders() }
      );

      return { success: true, data: response.data };
    } catch (error) {
      return { success: false, error: 'Failed to update Jira ticket' };
    }
  }
}
