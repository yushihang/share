import { Settings as SettingsIcon } from '@mui/icons-material';
import { AppBar, Box, Chip, Container, CssBaseline, IconButton, Toolbar, Typography } from '@mui/material';
import { ThemeProvider } from '@mui/material/styles';
import { useEffect, useState } from 'react';
import { ConfigDialog } from './components/ConfigDialog';
import { FinalProcessingStep } from './components/FinalProcessingStep';
import { InputForm } from './components/InputForm';
import { PRSelector } from './components/PRSelector';
import { ProcessingStep } from './components/ProcessingStep';
import { ResultDisplay } from './components/ResultDisplay';
import { StepIndicator } from './components/StepIndicator';
import { ThemeToggle } from './components/ThemeToggle';
import { useReleaseProcess } from './hooks/useReleaseProcess';
import { darkTheme, lightTheme } from './theme/hsbcTheme';
import { AppConfig, ReleaseData, ReleaseStep } from './types';
import { loadConfig } from './utils/config';

function App() {
  const [configOpen, setConfigOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState<ReleaseStep>('input');
  const [releaseData, setReleaseData] = useState<ReleaseData | null>(null);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme-mode');
    return saved === 'dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  // Release process hook
  const releaseProcess = useReleaseProcess();

  useEffect(() => {
    setConfig(loadConfig());
  }, []);

  useEffect(() => {
    localStorage.setItem('theme-mode', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  const currentTheme = isDarkMode ? darkTheme : lightTheme;

  const handleStepComplete = async (step: ReleaseStep, data?: Partial<ReleaseData>) => {
    if (data) {
      setReleaseData(prev => ({ ...prev, ...data }) as ReleaseData);
    }

    if (step === 'input' && releaseData) {
      // Start the processing steps
      setCurrentStep('processing');
    } else {
      // Define step progression for other steps
      const stepOrder: ReleaseStep[] = ['input', 'processing', 'pr-selection', 'final-processing', 'result'];
      const currentIndex = stepOrder.indexOf(step);
      const nextStep = stepOrder[currentIndex + 1];

      if (nextStep) {
        setCurrentStep(nextStep);
      }
    }
  };

  const handleBackToStep = (step: ReleaseStep) => {
    setCurrentStep(step);
  };

  const handleRetryStep = async (stepName: string) => {
    if (!releaseData) return;

    try {
      switch (stepName) {
        case 'createJiraTicket':
          await releaseProcess.createJiraTicket(releaseData);
          break;
        case 'updateJiraTicket':
          await releaseProcess.updateJiraTicket(releaseData);
          break;
        case 'createGitTag':
          await releaseProcess.createGitTag(releaseData.newTag, releaseData.commitHash);
          break;
        case 'fetchPullRequests':
          const pullRequests = await releaseProcess.fetchPullRequests(releaseData.previousTag, releaseData.newTag);
          setReleaseData(prev => ({ ...prev!, pullRequests }));
          break;
        case 'updateTicketWithPRs':
          if (releaseData.selectedPRs && releaseData.pullRequests) {
            await releaseProcess.updateTicketWithPRs(releaseData.selectedPRs, releaseData.pullRequests);
          }
          break;
        case 'generateReleaseNotes':
          const finalText = await releaseProcess.generateReleaseNotes(releaseData);
          setReleaseData(prev => ({ ...prev!, finalText }));
          break;
        default:
          console.warn('Unknown step:', stepName);
      }
    } catch (error) {
      console.error('Retry failed:', error);
    }
  };

  const handleContinueToPRSelection = () => {
    setCurrentStep('pr-selection');
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 'input':
        return <InputForm onComplete={data => handleStepComplete('input', data)} releaseData={releaseData} />;
      case 'processing':
        return (
          <ProcessingStep
            stepStates={releaseProcess.stepStates}
            onRetry={handleRetryStep}
            onContinue={handleContinueToPRSelection}
            releaseData={releaseData || undefined}
            onStart={async () => {
              if (releaseData) {
                try {
                  // Step 2: Create Jira ticket
                  const jiraTicket = await releaseProcess.createJiraTicket(releaseData);

                  // Step 3: Update Jira ticket (use the ticket key from the created ticket)
                  await releaseProcess.updateJiraTicket(releaseData);

                  // Step 4: Create Git tag
                  await releaseProcess.createGitTag(releaseData.newTag, releaseData.commitHash);

                  // Step 5: Fetch pull requests
                  const pullRequests = await releaseProcess.fetchPullRequests(
                    releaseData.previousTag,
                    releaseData.newTag
                  );

                  // Update release data with results
                  setReleaseData(prev => ({
                    ...prev!,
                    jiraTicketId: jiraTicket.key,
                    jiraTicketUrl: jiraTicket.url,
                    gitTagCreated: true,
                    pullRequests,
                  }));
                } catch (error) {
                  console.error('Processing failed:', error);
                }
              }
            }}
          />
        );
      case 'pr-selection':
        return (
          <PRSelector
            onComplete={async selectedPRs => {
              if (releaseData && releaseData.pullRequests) {
                // Update release data with selected PRs and move to final processing
                setReleaseData(prev => ({
                  ...prev!,
                  selectedPRs,
                }));
                setCurrentStep('final-processing');
              }
            }}
            onBack={() => handleBackToStep('input')}
            releaseData={releaseData}
          />
        );
      case 'final-processing':
        return (
          <FinalProcessingStep
            stepStates={releaseProcess.stepStates}
            onRetry={handleRetryStep}
            releaseData={releaseData || undefined}
            onContinue={() => {
              if (releaseData) {
                setCurrentStep('result');
              }
            }}
            onStart={async () => {
              if (releaseData && releaseData.selectedPRs && releaseData.pullRequests) {
                try {
                  // Step 7: Update ticket with selected PRs
                  await releaseProcess.updateTicketWithPRs(releaseData.selectedPRs, releaseData.pullRequests);

                  // Step 8: Generate release notes
                  const finalText = await releaseProcess.generateReleaseNotes({
                    ...releaseData,
                    selectedPRs: releaseData.selectedPRs,
                  });

                  // Update release data
                  setReleaseData(prev => ({
                    ...prev!,
                    finalText,
                    jiraTicketUpdated: true,
                  }));
                } catch (error) {
                  console.error('Failed to complete final steps:', error);
                }
              }
            }}
          />
        );
      case 'result':
        return (
          <ResultDisplay
            releaseData={releaseData}
            onBack={() => handleBackToStep('pr-selection')}
            onRestart={() => {
              setCurrentStep('input');
              setReleaseData(null);
              releaseProcess.resetStates();
            }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <ThemeProvider theme={currentTheme}>
      <CssBaseline />
      <Box sx={{ minHeight: '100vh', backgroundColor: 'background.default' }}>
        <AppBar position="static" elevation={0}>
          <Toolbar>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              HSBC Release Notes Tool
            </Typography>
            {config && (
              <Chip
                label={`${config.azureOrg}/${config.azureProject}/${config.azureRepo}`}
                variant="outlined"
                size="small"
                sx={{
                  mr: 2,
                  backgroundColor: 'rgba(255, 255, 255, 0.1)',
                  color: 'white',
                  borderColor: 'rgba(255, 255, 255, 0.3)',
                }}
              />
            )}
            <ThemeToggle isDark={isDarkMode} onToggle={() => setIsDarkMode(!isDarkMode)} />
            <IconButton color="inherit" onClick={() => setConfigOpen(true)} sx={{ ml: 2 }}>
              <SettingsIcon />
            </IconButton>
          </Toolbar>
        </AppBar>

        <Container maxWidth="lg" sx={{ py: 4 }}>
          <StepIndicator currentStep={currentStep} />
          <Box sx={{ mt: 4 }}>{renderCurrentStep()}</Box>
        </Container>
      </Box>
      <ConfigDialog
        open={configOpen}
        onClose={() => setConfigOpen(false)}
        onConfigUpdate={() => setConfig(loadConfig())}
      />
    </ThemeProvider>
  );
}

export default App;
