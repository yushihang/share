import { ArrowBack, CheckBox, CheckBoxOutlineBlank } from '@mui/icons-material';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Checkbox,
  Chip,
  Divider,
  FormControlLabel,
  List,
  ListItem,
  ListItemButton,
  ListItemText,
  Typography,
} from '@mui/material';
import { useEffect, useState } from 'react';
import { PRSelectorProps, PullRequest } from '../types';

export function PRSelector({ onComplete, onBack, releaseData }: PRSelectorProps) {
  const [selectedPRs, setSelectedPRs] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);

  // Mock data for demonstration - replace with actual API call
  const mockPRs: PullRequest[] = [
    {
      id: '1',
      title: 'Add new authentication feature',
      author: 'John Doe',
      url: 'https://dev.azure.com/project/pullrequest/1',
      mergedAt: '2024-01-15T10:30:00Z',
      description: 'Implemented OAuth2 authentication flow',
    },
    {
      id: '2',
      title: 'Fix login page styling issues',
      author: 'Jane Smith',
      url: 'https://dev.azure.com/project/pullrequest/2',
      mergedAt: '2024-01-16T14:20:00Z',
      description: 'Resolved CSS conflicts and improved responsive design',
    },
    {
      id: '3',
      title: 'Update API documentation',
      author: 'Mike Johnson',
      url: 'https://dev.azure.com/project/pullrequest/3',
      mergedAt: '2024-01-17T09:15:00Z',
      description: 'Added comprehensive API documentation for new endpoints',
    },
  ];

  const pullRequests = releaseData?.pullRequests || mockPRs;

  useEffect(() => {
    // Initialize with all PRs selected
    setSelectedPRs(pullRequests.map(pr => pr.id));
    setSelectAll(true);
  }, [pullRequests]);

  const handlePRToggle = (prId: string) => {
    setSelectedPRs(prev => {
      const newSelection = prev.includes(prId) ? prev.filter(id => id !== prId) : [...prev, prId];

      setSelectAll(newSelection.length === pullRequests.length);
      return newSelection;
    });
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedPRs([]);
      setSelectAll(false);
    } else {
      setSelectedPRs(pullRequests.map(pr => pr.id));
      setSelectAll(true);
    }
  };

  const handleContinue = () => {
    onComplete(selectedPRs);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Card elevation={2}>
      <CardContent sx={{ p: 4 }}>
        {/* Display input information */}
        {releaseData && (
          <Box
            sx={{
              mb: 3,
              p: 2,
              backgroundColor: 'background.paper',
              borderRadius: 1,
              border: 1,
              borderColor: 'divider',
            }}
          >
            <Typography variant="h6" gutterBottom>
              Release Information
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Commit Hash:
                </Typography>
                <Typography variant="body1" sx={{ fontFamily: 'monospace' }}>
                  {releaseData.commitHash}
                </Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Previous Tag:
                </Typography>
                <Typography variant="body1">{releaseData.previousTag}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  New Tag:
                </Typography>
                <Typography variant="body1">{releaseData.newTag}</Typography>
              </Box>
            </Box>
          </Box>
        )}

        <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
          <Button startIcon={<ArrowBack />} onClick={onBack} sx={{ mr: 2 }}>
            Back
          </Button>
          <Typography variant="h5">Select Pull Requests</Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Choose which pull requests to include in the release notes.
          {pullRequests.length > 0 &&
            ` Found ${pullRequests.length} PRs between ${releaseData?.previousTag} and ${releaseData?.newTag}.`}
        </Typography>

        {pullRequests.length === 0 ? (
          <Alert severity="warning" sx={{ mb: 3 }}>
            No pull requests found between the specified tags. Please check your tag names and try again.
          </Alert>
        ) : (
          <>
            <Box sx={{ mb: 2 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={selectAll}
                    onChange={handleSelectAll}
                    icon={<CheckBoxOutlineBlank />}
                    checkedIcon={<CheckBox />}
                  />
                }
                label={
                  <Typography variant="subtitle1">
                    Select All ({selectedPRs.length}/{pullRequests.length})
                  </Typography>
                }
              />
            </Box>

            <Divider sx={{ mb: 2 }} />

            <List sx={{ maxHeight: 400, overflow: 'auto', border: 1, borderColor: 'divider', borderRadius: 1 }}>
              {pullRequests.map((pr, index) => (
                <ListItem key={pr.id} disablePadding>
                  <ListItemButton dense onClick={() => handlePRToggle(pr.id)} sx={{ px: 2 }}>
                    <Checkbox checked={selectedPRs.includes(pr.id)} tabIndex={-1} disableRipple sx={{ mr: 2 }} />
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                          <Typography variant="subtitle2" sx={{ flex: 1 }}>
                            {pr.title}
                          </Typography>
                          <Chip label={pr.author} size="small" variant="outlined" />
                          <Chip label={formatDate(pr.mergedAt)} size="small" variant="outlined" color="primary" />
                        </Box>
                      }
                      secondary={
                        <>
                          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                            {pr.description}
                          </Typography>
                          <Typography variant="caption" color="primary">
                            <a href={pr.url} target="_blank" rel="noopener noreferrer">
                              View PR #{pr.id}
                            </a>
                          </Typography>
                        </>
                      }
                    />
                  </ListItemButton>
                  {index < pullRequests.length - 1 && <Divider />}
                </ListItem>
              ))}
            </List>

            <Alert severity="info" sx={{ mt: 3, mb: 3 }}>
              <Typography variant="body2">
                <strong>Next step:</strong> The selected PRs will be used to update the Jira ticket and generate the
                final release notes text.
              </Typography>
            </Alert>
          </>
        )}

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography variant="body2" color="text.secondary">
            {selectedPRs.length} of {pullRequests.length} PRs selected
          </Typography>
          <Button variant="contained" size="large" onClick={handleContinue} disabled={selectedPRs.length === 0}>
            Continue with Selected PRs
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
}
