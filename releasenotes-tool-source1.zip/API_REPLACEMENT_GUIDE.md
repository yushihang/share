# API Replacement Guide

这个指南说明如何将模拟API替换为真实的API调用。

## 当前状态

目前应用使用的是模拟API (`src/services/mockApi.ts`)，它包含：

- 随机延迟模拟 (800-2000ms)
- 随机失败率 (2%-15%)
- 自动重试机制 (最多3次)
- 详细的错误信息

## 替换步骤

### 1. 创建真实API文件

复制 `src/services/realApi.ts` 作为模板，并根据你的实际API端点进行修改。

### 2. 更新环境变量

在 `.env` 文件中添加以下变量：

```env
# Jira API 配置
REACT_APP_JIRA_API_URL=https://your-jira-instance.com/rest/api/2
REACT_APP_JIRA_USERNAME=your-username
REACT_APP_JIRA_API_TOKEN=your-api-token
REACT_APP_JIRA_BASE_URL=https://your-jira-instance.com

# Azure DevOps API 配置
REACT_APP_AZURE_DEVOPS_API_URL=https://dev.azure.com/hsbccst/WholesaleOpenAI/_apis
REACT_APP_AZURE_DEVOPS_TOKEN=your-pat-token
REACT_APP_AZURE_DEVOPS_BASE_URL=https://dev.azure.com/hsbccst/WholesaleOpenAI
```

### 3. 替换API导入

在 `src/hooks/useReleaseProcess.ts` 中：

```typescript
// 将这行
import { mockApi, ApiResponse } from '../services/mockApi';

// 替换为
import { realApi, ApiResponse } from '../services/realApi';

// 将这行
const api = mockApi;

// 替换为
const api = realApi;
```

### 4. 更新API配置

在 `src/services/realApi.ts` 中更新以下内容：

- **Jira项目键**: 将 `'REL'` 替换为你的实际项目键
- **Issue类型**: 将 `'Task'` 替换为你的实际issue类型
- **Azure DevOps仓库ID**: 将 `'your-repo-id'` 替换为实际仓库ID

### 5. 测试API连接

在替换之前，建议先测试各个API端点的连接性：

```typescript
// 测试Jira API
const testJiraConnection = async () => {
  try {
    const response = await jiraApi.get('/myself');
    console.log('Jira connection successful:', response.data);
  } catch (error) {
    console.error('Jira connection failed:', error);
  }
};

// 测试Azure DevOps API
const testAzureConnection = async () => {
  try {
    const response = await azureApi.get('/git/repositories');
    console.log('Azure DevOps connection successful:', response.data);
  } catch (error) {
    console.error('Azure DevOps connection failed:', error);
  }
};
```

## API函数说明

### 1. createJiraTicket

- **功能**: 创建Jira工单
- **参数**: `releaseData` (发布数据)
- **返回**: Jira工单信息

### 2. updateJiraTicket

- **功能**: 更新Jira工单信息
- **参数**: `ticketKey` (工单键), `releaseData` (发布数据)
- **返回**: 更新后的工单信息

### 3. createGitTag

- **功能**: 创建Git标签
- **参数**: `tagName` (标签名), `commitHash` (提交哈希)
- **返回**: 标签创建信息

### 4. fetchPullRequests

- **功能**: 获取两个标签之间的PR列表
- **参数**: `fromTag` (起始标签), `toTag` (结束标签)
- **返回**: PR列表

### 5. updateTicketWithPRs

- **功能**: 用选中的PR更新Jira工单
- **参数**: `ticketKey` (工单键), `selectedPRs` (选中的PR ID列表), `allPRs` (所有PR列表)
- **返回**: 更新后的工单信息

### 6. generateReleaseNotes

- **功能**: 生成发布说明
- **参数**: `releaseData` (发布数据)
- **返回**: 格式化的发布说明文本

## 错误处理

所有API函数都返回统一的响应格式：

```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}
```

- `success`: 操作是否成功
- `data`: 成功时的数据
- `error`: 失败时的错误信息

## 重试机制

应用使用TanStack Query进行自动重试：

- 默认重试次数: 2次
- 重试延迟: 1000ms
- 可在 `useReleaseProcess.ts` 中调整

## 注意事项

1. **API权限**: 确保你的API令牌有足够的权限执行所有操作
2. **速率限制**: 注意API的速率限制，必要时添加延迟
3. **错误处理**: 确保所有API调用都有适当的错误处理
4. **数据格式**: 确保返回的数据格式与模拟API一致
5. **测试**: 在生产环境使用前，充分测试所有功能

## 故障排除

### 常见问题

1. **CORS错误**: 确保API服务器允许跨域请求
2. **认证失败**: 检查API令牌是否有效
3. **权限不足**: 确认用户有执行操作的权限
4. **网络超时**: 增加超时时间或添加重试逻辑

### 调试技巧

1. 在浏览器开发者工具中查看网络请求
2. 使用console.log输出API响应
3. 检查环境变量是否正确设置
4. 验证API端点URL是否正确
