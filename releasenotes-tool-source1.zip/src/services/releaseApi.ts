import axios from 'axios';
import { JiraTicket, PullRequest, ReleaseData } from '../types';
import { loadConfig } from '../utils/config';

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// Configuration for API calls
interface ApiConfig {
  jiraBaseUrl: string;
  jiraPat: string;
  azureOrg: string;
  azureProject: string;
  azureRepo: string;
  azurePat: string;
}

// Get configuration
const getConfig = (): ApiConfig => {
  const config = loadConfig();
  return {
    jiraBaseUrl: config.jiraBaseUrl,
    jiraPat: config.jiraPat,
    azureOrg: config.azureOrg,
    azureProject: config.azureProject,
    azureRepo: config.azureRepo,
    azurePat: config.azurePat,
  };
};

// Jira API service
class JiraApiService {
  private baseUrl: string;
  private token: string;

  constructor(config: ApiConfig) {
    this.baseUrl = `${config.jiraBaseUrl}/rest/api/3`;
    this.token = config.jiraPat;
  }

  private getHeaders() {
    return {
      Authorization: `Bearer ${this.token}`,
      'Content-Type': 'application/json',
    };
  }

  // Create a new Jira ticket
  async createTicket(releaseData: ReleaseData): Promise<ApiResponse<JiraTicket>> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/issue`,
        {
          fields: {
            project: {
              key: 'REL', // You can make this configurable
            },
            summary: `Release ${releaseData.newTag}`,
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: `Release notes for version ${releaseData.newTag}`,
                    },
                  ],
                },
              ],
            },
            issuetype: {
              name: 'Task',
            },
          },
        },
        { headers: this.getHeaders() }
      );

      return {
        success: true,
        data: {
          id: response.data.id,
          key: response.data.key,
          summary: response.data.fields.summary,
          description: response.data.fields.description?.content?.[0]?.content?.[0]?.text || '',
          status: response.data.fields.status?.name || 'To Do',
          reporter: response.data.fields.reporter?.emailAddress || '',
          created: response.data.fields.created,
          updated: response.data.fields.updated,
          url: `${this.baseUrl.replace('/rest/api/3', '')}/browse/${response.data.key}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create Jira ticket',
      };
    }
  }

  // Update an existing Jira ticket
  async updateTicket(ticketKey: string, releaseData: ReleaseData): Promise<ApiResponse<JiraTicket>> {
    try {
      const response = await axios.put(
        `${this.baseUrl}/issue/${ticketKey}`,
        {
          fields: {
            summary: `Release ${releaseData.newTag}`,
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: `Release notes for version ${releaseData.newTag}\n\nCommit: ${releaseData.commitHash}\nPrevious Tag: ${releaseData.previousTag}\nNew Tag: ${releaseData.newTag}`,
                    },
                  ],
                },
              ],
            },
          },
        },
        { headers: this.getHeaders() }
      );

      return {
        success: true,
        data: {
          id: response.data.id,
          key: ticketKey,
          summary: response.data.fields.summary,
          description: response.data.fields.description?.content?.[0]?.content?.[0]?.text || '',
          status: response.data.fields.status?.name || 'In Progress',
          reporter: response.data.fields.reporter?.emailAddress || '',
          created: response.data.fields.created,
          updated: response.data.fields.updated,
          url: `${this.baseUrl.replace('/rest/api/3', '')}/browse/${ticketKey}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update Jira ticket',
      };
    }
  }

  // Update ticket with selected PRs
  async updateTicketWithPRs(
    ticketKey: string,
    selectedPRs: string[],
    allPRs: PullRequest[]
  ): Promise<ApiResponse<JiraTicket>> {
    try {
      const selectedPRDetails = allPRs.filter(pr => selectedPRs.includes(pr.id));
      const prList = selectedPRDetails.map(pr => `- ${pr.title} (by ${pr.author})`).join('\n');

      const response = await axios.put(
        `${this.baseUrl}/issue/${ticketKey}`,
        {
          fields: {
            description: {
              type: 'doc',
              version: 1,
              content: [
                {
                  type: 'paragraph',
                  content: [
                    {
                      type: 'text',
                      text: `Release notes with selected PRs:\n\n${prList}`,
                    },
                  ],
                },
              ],
            },
          },
        },
        { headers: this.getHeaders() }
      );

      return {
        success: true,
        data: {
          id: response.data.id,
          key: ticketKey,
          summary: response.data.fields.summary,
          description: response.data.fields.description?.content?.[0]?.content?.[0]?.text || '',
          status: response.data.fields.status?.name || 'Done',
          reporter: response.data.fields.reporter?.emailAddress || '',
          created: response.data.fields.created,
          updated: response.data.fields.updated,
          url: `${this.baseUrl.replace('/rest/api/3', '')}/browse/${ticketKey}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update ticket with PRs',
      };
    }
  }
}

// Azure DevOps API service
class AzureDevOpsApiService {
  private baseUrl: string;
  private token: string;
  private org: string;
  private project: string;
  private repo: string;

  constructor(config: ApiConfig) {
    this.baseUrl = `https://dev.azure.com/${config.azureOrg}/${config.azureProject}/_apis`;
    this.token = config.azurePat;
    this.org = config.azureOrg;
    this.project = config.azureProject;
    this.repo = config.azureRepo;
  }

  private getHeaders() {
    return {
      Authorization: `Basic ${btoa(`:${this.token}`)}`,
      'Content-Type': 'application/json',
    };
  }

  // Create a Git tag
  async createTag(tagName: string, commitHash: string): Promise<ApiResponse<any>> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/git/repositories/${this.repo}/annotatedtags`,
        {
          name: tagName,
          taggedObject: {
            objectId: commitHash,
          },
          message: `Release ${tagName}`,
        },
        { headers: this.getHeaders() }
      );

      return {
        success: true,
        data: {
          name: response.data.name,
          objectId: response.data.taggedObject.objectId,
          url: `https://dev.azure.com/${this.org}/${this.project}/_git/${this.repo}/tags/${tagName}`,
          createdBy: response.data.createdBy,
          creationDate: response.data.createdDate,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create Git tag',
      };
    }
  }

  // Fetch pull requests between two tags
  async fetchPullRequests(fromTag: string, toTag: string): Promise<ApiResponse<PullRequest[]>> {
    try {
      // First, get the commits between the two tags
      const commitsResponse = await axios.get(`${this.baseUrl}/git/repositories/${this.repo}/commits`, {
        headers: this.getHeaders(),
        params: {
          fromDate: fromTag,
          toDate: toTag,
          $top: 1000,
        },
      });

      // Then, get pull requests that were merged in this range
      const prsResponse = await axios.get(`${this.baseUrl}/git/repositories/${this.repo}/pullrequests`, {
        headers: this.getHeaders(),
        params: {
          'searchCriteria.status': 'completed',
          'searchCriteria.targetRefName': 'refs/heads/main',
          $top: 1000,
        },
      });

      // Filter PRs that were merged between the two tags
      const commitIds = commitsResponse.data.value.map((commit: any) => commit.commitId);
      const filteredPRs = prsResponse.data.value.filter((pr: any) =>
        commitIds.includes(pr.lastMergeTargetCommit.commitId)
      );

      const pullRequests: PullRequest[] = filteredPRs.map((pr: any) => ({
        id: pr.pullRequestId.toString(),
        title: pr.title,
        author: pr.createdBy.displayName,
        url: pr.url,
        mergedAt: pr.closedDate,
        description: pr.description || '',
      }));

      return {
        success: true,
        data: pullRequests,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch pull requests',
      };
    }
  }
}

// Main API service class
export class ReleaseApiService {
  private jiraService: JiraApiService;
  private azureService: AzureDevOpsApiService;

  constructor() {
    const config = getConfig();
    this.jiraService = new JiraApiService(config);
    this.azureService = new AzureDevOpsApiService(config);
  }

  // Step 2: Create Jira ticket
  async createJiraTicket(releaseData: ReleaseData): Promise<ApiResponse<JiraTicket>> {
    return this.jiraService.createTicket(releaseData);
  }

  // Step 3: Update Jira ticket
  async updateJiraTicket(ticketKey: string, releaseData: ReleaseData): Promise<ApiResponse<JiraTicket>> {
    return this.jiraService.updateTicket(ticketKey, releaseData);
  }

  // Step 4: Create Git tag
  async createGitTag(tagName: string, commitHash: string): Promise<ApiResponse<any>> {
    return this.azureService.createTag(tagName, commitHash);
  }

  // Step 5: Fetch pull requests
  async fetchPullRequests(fromTag: string, toTag: string): Promise<ApiResponse<PullRequest[]>> {
    return this.azureService.fetchPullRequests(fromTag, toTag);
  }

  // Step 7: Update ticket with selected PRs
  async updateTicketWithPRs(
    ticketKey: string,
    selectedPRs: string[],
    allPRs: PullRequest[]
  ): Promise<ApiResponse<JiraTicket>> {
    return this.jiraService.updateTicketWithPRs(ticketKey, selectedPRs, allPRs);
  }

  // Step 8: Generate release notes (this is local processing, but you could call an external service)
  async generateReleaseNotes(releaseData: ReleaseData): Promise<ApiResponse<string>> {
    try {
      const selectedPRs = releaseData.pullRequests?.filter(pr => releaseData.selectedPRs?.includes(pr.id)) || [];

      const releaseNotes = `# Release Notes - ${releaseData.newTag}

## Overview
This release includes ${selectedPRs.length} pull requests with various improvements and bug fixes.

## Changes

${selectedPRs
  .map(pr => {
    const category = pr.title.toLowerCase().includes('fix')
      ? 'Bug Fixes'
      : pr.title.toLowerCase().includes('feature')
        ? 'New Features'
        : pr.title.toLowerCase().includes('doc')
          ? 'Documentation'
          : pr.title.toLowerCase().includes('test')
            ? 'Testing'
            : pr.title.toLowerCase().includes('perf')
              ? 'Performance'
              : 'Other Changes';

    return `### ${category}
- **${pr.title}** - ${pr.description}
  - Author: ${pr.author}
  - PR: [#${pr.id}](${pr.url})`;
  })
  .join('\n\n')}

## Technical Details
- **Previous Tag:** ${releaseData.previousTag}
- **New Tag:** ${releaseData.newTag}
- **Commit Hash:** ${releaseData.commitHash}
- **Jira Ticket:** [${releaseData.jiraTicketId}](${releaseData.jiraTicketUrl})

## Deployment Notes
Please ensure all database migrations are applied before deploying this release.

Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`;

      return {
        success: true,
        data: releaseNotes,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate release notes',
      };
    }
  }
}

// Export a singleton instance
export const releaseApiService = new ReleaseApiService();
