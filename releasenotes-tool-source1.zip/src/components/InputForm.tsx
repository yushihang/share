import { ArrowForward } from '@mui/icons-material';
import { Alert, Box, Button, Card, CardContent, TextField, Typography } from '@mui/material';
import { useState } from 'react';
import { InputFormProps } from '../types';

export function InputForm({ onComplete, releaseData }: InputFormProps) {
  const [formData, setFormData] = useState({
    commitHash: releaseData?.commitHash || '',
    previousTag: releaseData?.previousTag || '',
    newTag: releaseData?.newTag || '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.commitHash.trim()) {
      newErrors.commitHash = 'Commit hash is required';
    } else if (!/^[a-fA-F0-9]{7,40}$/.test(formData.commitHash)) {
      newErrors.commitHash = 'Please enter a valid commit hash (7-40 characters)';
    }

    if (!formData.previousTag.trim()) {
      newErrors.previousTag = 'Previous tag is required';
    }

    if (!formData.newTag.trim()) {
      newErrors.newTag = 'New tag is required';
    }

    if (formData.previousTag === formData.newTag) {
      newErrors.newTag = 'New tag must be different from previous tag';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onComplete(formData);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <Card elevation={2}>
      <CardContent sx={{ p: 4 }}>
        <Typography variant="h5" gutterBottom>
          Release Information
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Please provide the necessary information to generate release notes
        </Typography>

        <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
          <TextField
            fullWidth
            label="Commit Hash"
            placeholder="e.g., a1b2c3d4e5f6"
            value={formData.commitHash}
            onChange={e => handleInputChange('commitHash', e.target.value)}
            error={!!errors.commitHash}
            helperText={errors.commitHash || 'Enter the commit hash from Azure DevOps'}
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            label="Previous Release Tag"
            placeholder="e.g., v1.0.0, release-2024-01, etc."
            value={formData.previousTag}
            onChange={e => handleInputChange('previousTag', e.target.value)}
            error={!!errors.previousTag}
            helperText={errors.previousTag || 'Enter the tag of the previous release'}
            sx={{ mb: 3 }}
          />

          <TextField
            fullWidth
            label="New Release Tag"
            placeholder="e.g., v1.1.0, release-2024-02, etc."
            value={formData.newTag}
            onChange={e => handleInputChange('newTag', e.target.value)}
            error={!!errors.newTag}
            helperText={errors.newTag || 'Enter the tag for this new release'}
            sx={{ mb: 4 }}
          />

          <Alert severity="info" sx={{ mb: 3 }}>
            <Typography variant="body2">
              <strong>What happens next:</strong> The system will automatically create a Jira ticket, update its
              information, create a Git tag, and fetch all PRs between the two tags.
            </Typography>
          </Alert>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button
              type="submit"
              variant="contained"
              size="large"
              endIcon={<ArrowForward />}
              disabled={!formData.commitHash || !formData.previousTag || !formData.newTag}
            >
              Start Release Process
            </Button>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
}
