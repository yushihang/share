import axios from 'axios';
import { JiraTicket, PullRequest, ReleaseData } from '../types';
import { ApiResponse, MockApiConfig } from './mockApi';

// Example of how to replace mock API with real API calls
// Replace the mockApi import in useReleaseProcess.ts with this realApi

// Configuration for your real API endpoints
const API_CONFIG = {
  jira: {
    baseURL: process.env.REACT_APP_JIRA_API_URL || 'https://your-jira-instance.com/rest/api/2',
    auth: {
      username: process.env.REACT_APP_JIRA_USERNAME || '',
      password: process.env.REACT_APP_JIRA_API_TOKEN || '',
    },
  },
  azureDevOps: {
    baseURL: process.env.REACT_APP_AZURE_DEVOPS_API_URL || 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_apis',
    token: process.env.REACT_APP_AZURE_DEVOPS_TOKEN || '',
  },
};

// Create axios instances
const jiraApi = axios.create({
  baseURL: API_CONFIG.jira.baseURL,
  auth: API_CONFIG.jira.auth,
  headers: {
    'Content-Type': 'application/json',
  },
});

const azureApi = axios.create({
  baseURL: API_CONFIG.azureDevOps.baseURL,
  headers: {
    Authorization: `Basic ${btoa(`:${API_CONFIG.azureDevOps.token}`)}`,
    'Content-Type': 'application/json',
  },
});

// Real API implementation - replace mockApi with this
export const realApi = {
  // Step 2: Create Jira ticket
  createJiraTicket: async (
    releaseData: ReleaseData,
    config?: MockApiConfig // Keep config for compatibility, but ignore in real API
  ): Promise<ApiResponse<JiraTicket>> => {
    try {
      const response = await jiraApi.post('/issue', {
        fields: {
          project: { key: 'REL' }, // Replace with your project key
          summary: `Release ${releaseData.newTag}`,
          description: `Release notes for version ${releaseData.newTag}`,
          issuetype: { name: 'Task' }, // Replace with your issue type
        },
      });

      return {
        success: true,
        data: {
          id: response.data.id,
          key: response.data.key,
          summary: response.data.fields.summary,
          description: response.data.fields.description,
          status: response.data.fields.status.name,
          reporter: response.data.fields.reporter.displayName,
          created: response.data.fields.created,
          updated: response.data.fields.updated,
          url: `${process.env.REACT_APP_JIRA_BASE_URL}/browse/${response.data.key}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create Jira ticket',
      };
    }
  },

  // Step 3: Update Jira ticket
  updateJiraTicket: async (
    ticketKey: string,
    releaseData: ReleaseData,
    config?: MockApiConfig
  ): Promise<ApiResponse<JiraTicket>> => {
    try {
      const response = await jiraApi.put(`/issue/${ticketKey}`, {
        fields: {
          summary: `Release ${releaseData.newTag}`,
          description: `Release notes for version ${releaseData.newTag}\n\nCommit: ${releaseData.commitHash}\nPrevious Tag: ${releaseData.previousTag}\nNew Tag: ${releaseData.newTag}`,
        },
      });

      // Fetch updated ticket details
      const ticketResponse = await jiraApi.get(`/issue/${ticketKey}`);
      const ticket = ticketResponse.data;

      return {
        success: true,
        data: {
          id: ticket.id,
          key: ticket.key,
          summary: ticket.fields.summary,
          description: ticket.fields.description,
          status: ticket.fields.status.name,
          reporter: ticket.fields.reporter.displayName,
          created: ticket.fields.created,
          updated: ticket.fields.updated,
          url: `${process.env.REACT_APP_JIRA_BASE_URL}/browse/${ticket.key}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update Jira ticket',
      };
    }
  },

  // Step 4: Create Git tag
  createGitTag: async (tagName: string, commitHash: string, config?: MockApiConfig): Promise<ApiResponse<any>> => {
    try {
      const response = await azureApi.post(
        '/git/repositories/your-repo-id/refs',
        [
          {
            name: `refs/tags/${tagName}`,
            oldObjectId: '0000000000000000000000000000000000000000',
            newObjectId: commitHash,
          },
        ],
        {
          params: {
            'api-version': '6.0',
          },
        }
      );

      return {
        success: true,
        data: {
          name: tagName,
          objectId: commitHash,
          url: `${process.env.REACT_APP_AZURE_DEVOPS_BASE_URL}/_git/your-repo/tags/${tagName}`,
          createdBy: response.data.createdBy,
          creationDate: response.data.creationDate,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to create Git tag',
      };
    }
  },

  // Step 5: Fetch pull requests
  fetchPullRequests: async (
    fromTag: string,
    toTag: string,
    config?: MockApiConfig
  ): Promise<ApiResponse<PullRequest[]>> => {
    try {
      // First, get commits between tags
      const commitsResponse = await azureApi.get('/git/repositories/your-repo-id/commits', {
        params: {
          'api-version': '6.0',
          searchCriteria: {
            fromDate: fromTag,
            toDate: toTag,
          },
        },
      });

      // Then, get pull requests for those commits
      const prsResponse = await azureApi.get('/git/repositories/your-repo-id/pullrequests', {
        params: {
          'api-version': '6.0',
          status: 'completed',
        },
      });

      const pullRequests: PullRequest[] = prsResponse.data.value.map((pr: any) => ({
        id: pr.pullRequestId.toString(),
        title: pr.title,
        author: pr.createdBy.displayName,
        url: pr.url,
        mergedAt: pr.closedDate,
        description: pr.description || '',
      }));

      return {
        success: true,
        data: pullRequests,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch pull requests',
      };
    }
  },

  // Step 7: Update ticket with selected PRs
  updateTicketWithPRs: async (
    ticketKey: string,
    selectedPRs: string[],
    allPRs: PullRequest[],
    config?: MockApiConfig
  ): Promise<ApiResponse<JiraTicket>> => {
    try {
      const selectedPRDetails = allPRs.filter(pr => selectedPRs.includes(pr.id));
      const prList = selectedPRDetails.map(pr => `- ${pr.title} (by ${pr.author})`).join('\n');

      const response = await jiraApi.put(`/issue/${ticketKey}`, {
        fields: {
          description: `Release notes with selected PRs:\n\n${prList}`,
        },
      });

      // Fetch updated ticket details
      const ticketResponse = await jiraApi.get(`/issue/${ticketKey}`);
      const ticket = ticketResponse.data;

      return {
        success: true,
        data: {
          id: ticket.id,
          key: ticket.key,
          summary: ticket.fields.summary,
          description: ticket.fields.description,
          status: ticket.fields.status.name,
          reporter: ticket.fields.reporter.displayName,
          created: ticket.fields.created,
          updated: ticket.fields.updated,
          url: `${process.env.REACT_APP_JIRA_BASE_URL}/browse/${ticket.key}`,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to update ticket with PRs',
      };
    }
  },

  // Step 8: Generate release notes
  generateReleaseNotes: async (releaseData: ReleaseData, config?: MockApiConfig): Promise<ApiResponse<string>> => {
    try {
      const selectedPRs = releaseData.pullRequests?.filter(pr => releaseData.selectedPRs?.includes(pr.id)) || [];

      const releaseNotes = `# Release Notes - ${releaseData.newTag}

## Overview
This release includes ${selectedPRs.length} pull requests with various improvements and bug fixes.

## Changes

${selectedPRs
  .map(pr => {
    const category = pr.title.toLowerCase().includes('fix')
      ? 'Bug Fixes'
      : pr.title.toLowerCase().includes('feature')
        ? 'New Features'
        : pr.title.toLowerCase().includes('doc')
          ? 'Documentation'
          : pr.title.toLowerCase().includes('test')
            ? 'Testing'
            : pr.title.toLowerCase().includes('perf')
              ? 'Performance'
              : 'Other Changes';

    return `### ${category}
- **${pr.title}** - ${pr.description}
  - Author: ${pr.author}
  - PR: [#${pr.id}](${pr.url})`;
  })
  .join('\n\n')}

## Technical Details
- **Previous Tag:** ${releaseData.previousTag}
- **New Tag:** ${releaseData.newTag}
- **Commit Hash:** ${releaseData.commitHash}
- **Jira Ticket:** [${releaseData.jiraTicketId}](${releaseData.jiraTicketUrl})

## Deployment Notes
Please ensure all database migrations are applied before deploying this release.

Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`;

      return {
        success: true,
        data: releaseNotes,
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to generate release notes',
      };
    }
  },
};

// Usage instructions:
// 1. Replace the import in useReleaseProcess.ts:
//    import { realApi } from '../services/realApi';
//    const api = realApi;
//
// 2. Set up environment variables in your .env file:
//    REACT_APP_JIRA_API_URL=https://your-jira-instance.com/rest/api/2
//    REACT_APP_JIRA_USERNAME=your-username
//    REACT_APP_JIRA_API_TOKEN=your-api-token
//    REACT_APP_JIRA_BASE_URL=https://your-jira-instance.com
//    REACT_APP_AZURE_DEVOPS_API_URL=https://dev.azure.com/hsbccst/WholesaleOpenAI/_apis
//    REACT_APP_AZURE_DEVOPS_TOKEN=your-pat-token
//    REACT_APP_AZURE_DEVOPS_BASE_URL=https://dev.azure.com/hsbccst/WholesaleOpenAI
//
// 3. Update the repository ID and project keys in the API calls
// 4. Test with your actual endpoints
