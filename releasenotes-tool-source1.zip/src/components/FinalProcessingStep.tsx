import { CheckCircle, Error, Refresh, Schedule } from '@mui/icons-material';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Typography,
} from '@mui/material';
import { useEffect } from 'react';
import { ReleaseProcessState } from '../hooks/useReleaseProcess';
import { ReleaseData } from '../types';

interface FinalProcessingStepProps {
  stepStates: ReleaseProcessState;
  onRetry?: (stepName: string) => void;
  onContinue?: () => void;
  onStart?: () => Promise<void>;
  releaseData?: ReleaseData;
}

const finalStepConfig = {
  updateTicketWithPRs: {
    title: 'Update Ticket with PRs',
    description: 'Updating Jira ticket with selected PRs',
    icon: '📝',
  },
  generateReleaseNotes: {
    title: 'Generate Release Notes',
    description: 'Generating final release notes text',
    icon: '📄',
  },
};

export function FinalProcessingStep({
  stepStates,
  onRetry,
  onContinue,
  onStart,
  releaseData,
}: FinalProcessingStepProps) {
  // Auto-start final processing when component mounts
  useEffect(() => {
    if (onStart) {
      onStart();
    }
  }, [onStart]);
  const getStepIcon = (status: 'idle' | 'loading' | 'success' | 'error') => {
    switch (status) {
      case 'loading':
        return <CircularProgress size={20} />;
      case 'success':
        return <CheckCircle color="success" />;
      case 'error':
        return <Error color="error" />;
      default:
        return <Schedule color="disabled" />;
    }
  };

  const getStepColor = (status: 'idle' | 'loading' | 'success' | 'error') => {
    switch (status) {
      case 'loading':
        return 'primary';
      case 'success':
        return 'success';
      case 'error':
        return 'error';
      default:
        return 'default';
    }
  };

  // Define final steps
  const finalSteps = ['updateTicketWithPRs', 'generateReleaseNotes'];

  const finalStepsCompleted = finalSteps.every(
    stepName => stepStates[stepName as keyof typeof stepStates]?.status === 'success'
  );

  const hasErrors = Object.values(stepStates).some(state => state.status === 'error');
  const isLoading = Object.values(stepStates).some(state => state.status === 'loading');

  return (
    <Card elevation={2}>
      <CardContent sx={{ p: 4 }}>
        {/* Display input information */}
        {releaseData && (
          <Box
            sx={{
              mb: 3,
              p: 2,
              backgroundColor: 'background.paper',
              borderRadius: 1,
              border: 1,
              borderColor: 'divider',
            }}
          >
            <Typography variant="h6" gutterBottom>
              Release Information
            </Typography>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2 }}>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Commit Hash:
                </Typography>
                <Typography variant="body1" sx={{ fontFamily: 'monospace' }}>
                  {releaseData.commitHash}
                </Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  Previous Tag:
                </Typography>
                <Typography variant="body1">{releaseData.previousTag}</Typography>
              </Box>
              <Box>
                <Typography variant="body2" color="text.secondary">
                  New Tag:
                </Typography>
                <Typography variant="body1">{releaseData.newTag}</Typography>
              </Box>
            </Box>
          </Box>
        )}

        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Typography variant="h5" gutterBottom>
            Finalizing Release...
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 2 }}>
            {isLoading
              ? 'Please wait while we finalize your release...'
              : finalStepsCompleted
                ? 'Release finalized successfully!'
                : hasErrors
                  ? 'Some steps encountered errors. Please review and retry.'
                  : 'Preparing to finalize your release...'}
          </Typography>

          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
            <Chip
              label={`${
                finalSteps.filter(
                  (stepName: string) => stepStates[stepName as keyof typeof stepStates]?.status === 'success'
                ).length
              } of ${finalSteps.length} final steps completed`}
              color={finalStepsCompleted ? 'success' : hasErrors ? 'error' : 'primary'}
              variant="outlined"
              size="medium"
            />
          </Box>
        </Box>

        <List sx={{ mb: 3 }}>
          {Object.entries(stepStates)
            .filter(([stepName]) => finalSteps.includes(stepName))
            .map(([stepName, stepState]) => {
              const config = finalStepConfig[stepName as keyof typeof finalStepConfig];
              return (
                <ListItem
                  key={stepName}
                  sx={{
                    border: 1,
                    borderColor: 'divider',
                    borderRadius: 2,
                    mb: 1,
                    backgroundColor: stepState.status === 'loading' ? 'action.hover' : 'transparent',
                    transition: 'all 0.2s ease-in-out',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                    <ListItemIcon sx={{ minWidth: 40 }}>{getStepIcon(stepState.status)}</ListItemIcon>

                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            {config?.title || stepName}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {config?.icon}
                          </Typography>
                        </Box>
                      }
                      secondary={config?.description}
                    />

                    {stepState.status === 'error' && onRetry && (
                      <Button
                        size="small"
                        startIcon={<Refresh />}
                        onClick={() => onRetry(stepName)}
                        variant="outlined"
                        color="error"
                      >
                        Retry
                      </Button>
                    )}
                  </Box>

                  {/* Additional content outside of ListItemText to avoid HTML nesting issues */}
                  {stepState.error && (
                    <Box sx={{ mt: 1, ml: 6 }}>
                      <Alert severity="error" sx={{ py: 0 }}>
                        <Typography variant="caption">{stepState.error}</Typography>
                      </Alert>
                    </Box>
                  )}

                  {stepState.status === 'success' && stepState.data && (
                    <Box sx={{ mt: 1, ml: 6 }}>
                      {stepName === 'generateReleaseNotes' && (
                        <Chip label="Release notes generated" size="small" color="success" variant="outlined" />
                      )}
                    </Box>
                  )}
                </ListItem>
              );
            })}
        </List>

        {hasErrors && (
          <Alert severity="error" sx={{ mb: 3 }}>
            <Typography variant="body2">
              Some steps failed to complete. Please review the errors above and retry the failed steps.
            </Typography>
          </Alert>
        )}

        {finalStepsCompleted && onContinue && (
          <Box sx={{ textAlign: 'center' }}>
            <Alert severity="success" sx={{ mb: 3 }}>
              <Typography variant="body2">
                Release finalized successfully! You can now view the generated release notes.
              </Typography>
            </Alert>
            <Button variant="contained" size="large" onClick={onContinue}>
              View Release Notes
            </Button>
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
