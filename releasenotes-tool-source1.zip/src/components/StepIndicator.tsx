import { CheckCircle, Circle, RadioButtonUnchecked } from '@mui/icons-material';
import { Box, Paper, Step, StepLabel, Stepper, Typography } from '@mui/material';
import { StepIndicatorProps } from '../types';

const steps = [
  {
    label: 'Input Release Info',
    description: 'Enter commit hash, previous tag, and new tag',
  },
  {
    label: 'Processing',
    description: 'Creating Jira ticket and fetching PRs',
  },
  {
    label: 'Select PRs',
    description: 'Choose which PRs to include',
  },
  {
    label: 'Finalize',
    description: 'Update ticket and generate release notes',
  },
  {
    label: 'Result',
    description: 'Copy the generated release notes',
  },
];

export function StepIndicator({ currentStep }: StepIndicatorProps) {
  const getStepIndex = (step: string) => {
    const stepMap: Record<string, number> = {
      input: 0,
      processing: 1,
      'pr-selection': 2,
      'final-processing': 3,
      result: 4,
    };
    return stepMap[step] || 0;
  };

  const currentStepIndex = getStepIndex(currentStep);

  return (
    <Paper elevation={1} sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Release Notes Generation Progress
      </Typography>
      <Stepper activeStep={currentStepIndex} alternativeLabel>
        {steps.map((step, index) => (
          <Step key={step.label}>
            <StepLabel
              StepIconComponent={({ active, completed }) => {
                if (completed) {
                  return <CheckCircle color="success" />;
                }
                if (active) {
                  return <RadioButtonUnchecked color="primary" />;
                }
                return <Circle color="disabled" />;
              }}
            >
              <Box>
                <Typography variant="subtitle2" color={index <= currentStepIndex ? 'primary' : 'text.disabled'}>
                  {step.label}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {step.description}
                </Typography>
              </Box>
            </StepLabel>
          </Step>
        ))}
      </Stepper>
    </Paper>
  );
}
