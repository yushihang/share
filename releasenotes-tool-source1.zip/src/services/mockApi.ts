import { JiraTicket, PullRequest, ReleaseData } from '../types';

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// Configuration for mock API behavior
export interface MockApiConfig {
  // Base delay range (in milliseconds)
  minDelay: number;
  maxDelay: number;
  // Failure probability (0-1)
  failureRate: number;
  // Retry configuration
  maxRetries: number;
  retryDelay: number;
}

// Default configuration
const defaultConfig: MockApiConfig = {
  minDelay: 800,
  maxDelay: 2000,
  failureRate: 0.15, // 15% failure rate
  maxRetries: 3,
  retryDelay: 1000,
};

// Utility function to simulate API delay
const simulateDelay = async (config: MockApiConfig = defaultConfig): Promise<void> => {
  const delay = Math.random() * (config.maxDelay - config.minDelay) + config.minDelay;
  await new Promise(resolve => setTimeout(resolve, delay));
};

// Utility function to simulate random failure
const shouldFail = (config: MockApiConfig = defaultConfig): boolean => {
  return Math.random() < config.failureRate;
};

// Generic retry wrapper
const withRetry = async <T>(
  apiCall: () => Promise<ApiResponse<T>>,
  config: MockApiConfig = defaultConfig
): Promise<ApiResponse<T>> => {
  let lastError: string = '';

  for (let attempt = 1; attempt <= config.maxRetries; attempt++) {
    try {
      const result = await apiCall();

      if (result.success) {
        return result;
      } else {
        lastError = result.error || 'Unknown error';
        if (attempt < config.maxRetries) {
          console.log(`Attempt ${attempt} failed: ${lastError}, retrying...`);
          await new Promise(resolve => setTimeout(resolve, config.retryDelay));
        }
      }
    } catch (error) {
      lastError = error instanceof Error ? error.message : 'Unknown error';
      if (attempt < config.maxRetries) {
        console.log(`Attempt ${attempt} failed: ${lastError}, retrying...`);
        await new Promise(resolve => setTimeout(resolve, config.retryDelay));
      }
    }
  }

  return {
    success: false,
    error: `Failed after ${config.maxRetries} attempts. Last error: ${lastError}`,
  };
};

// Mock API functions - replace these with real API calls
export const mockApi = {
  // Step 2: Create Jira ticket
  createJiraTicket: async (
    releaseData: ReleaseData,
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.1 }
  ): Promise<ApiResponse<JiraTicket>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to create Jira ticket: Network timeout',
          'Failed to create Jira ticket: Invalid project key',
          'Failed to create Jira ticket: Permission denied',
          'Failed to create Jira ticket: Jira service unavailable',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      const ticketKey = `REL-${Date.now()}`;
      return {
        success: true,
        data: {
          id: '12345',
          key: ticketKey,
          summary: `Release ${releaseData.newTag}`,
          description: `Release notes for version ${releaseData.newTag}`,
          status: 'To Do',
          reporter: 'release-tool@hsbc.com',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          url: `https://jira.company.com/browse/${ticketKey}`,
        },
      };
    }, config);
  },

  // Step 3: Update Jira ticket
  updateJiraTicket: async (
    ticketKey: string,
    releaseData: ReleaseData,
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.05, minDelay: 500, maxDelay: 1200 }
  ): Promise<ApiResponse<JiraTicket>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to update Jira ticket: Permission denied',
          'Failed to update Jira ticket: Ticket not found',
          'Failed to update Jira ticket: Invalid field values',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      return {
        success: true,
        data: {
          id: '12345',
          key: ticketKey,
          summary: `Release ${releaseData.newTag}`,
          description: `Release notes for version ${releaseData.newTag}\n\nCommit: ${releaseData.commitHash}\nPrevious Tag: ${releaseData.previousTag}\nNew Tag: ${releaseData.newTag}`,
          status: 'In Progress',
          reporter: 'release-tool@hsbc.com',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          url: `https://jira.company.com/browse/${ticketKey}`,
        },
      };
    }, config);
  },

  // Step 4: Create Git tag
  createGitTag: async (
    tagName: string,
    commitHash: string,
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.08, minDelay: 400, maxDelay: 1000 }
  ): Promise<ApiResponse<any>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to create Git tag: Tag already exists',
          'Failed to create Git tag: Invalid commit hash',
          'Failed to create Git tag: Repository not found',
          'Failed to create Git tag: Insufficient permissions',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      return {
        success: true,
        data: {
          name: tagName,
          objectId: commitHash,
          url: `https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/tags/${tagName}`,
          createdBy: {
            displayName: 'Release Tool',
            uniqueName: 'release-tool@hsbc.com',
          },
          creationDate: new Date().toISOString(),
        },
      };
    }, config);
  },

  // Step 5: Fetch pull requests
  fetchPullRequests: async (
    fromTag: string,
    toTag: string,
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.03, minDelay: 1000, maxDelay: 2000 }
  ): Promise<ApiResponse<PullRequest[]>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to fetch pull requests: Repository not found',
          'Failed to fetch pull requests: Invalid tag range',
          'Failed to fetch pull requests: API rate limit exceeded',
          'Failed to fetch pull requests: Network connection error',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      // Generate mock PRs based on tag range
      const mockPRs: PullRequest[] = [
        {
          id: '1',
          title: 'Add new authentication feature',
          author: 'John Doe',
          url: 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/pullrequest/1',
          mergedAt: '2024-01-15T10:30:00Z',
          description: 'Implemented OAuth2 authentication flow with enhanced security',
        },
        {
          id: '2',
          title: 'Fix login page styling issues',
          author: 'Jane Smith',
          url: 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/pullrequest/2',
          mergedAt: '2024-01-16T14:20:00Z',
          description: 'Resolved CSS conflicts and improved responsive design for mobile devices',
        },
        {
          id: '3',
          title: 'Update API documentation',
          author: 'Mike Johnson',
          url: 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/pullrequest/3',
          mergedAt: '2024-01-17T09:15:00Z',
          description: 'Added comprehensive API documentation for new endpoints and updated examples',
        },
        {
          id: '4',
          title: 'Performance optimization for data processing',
          author: 'Sarah Wilson',
          url: 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/pullrequest/4',
          mergedAt: '2024-01-18T16:45:00Z',
          description: 'Optimized database queries and improved caching strategy',
        },
        {
          id: '5',
          title: 'Add unit tests for core modules',
          author: 'David Brown',
          url: 'https://dev.azure.com/hsbccst/WholesaleOpenAI/_git/ps-dev/pullrequest/5',
          mergedAt: '2024-01-19T11:30:00Z',
          description: 'Added comprehensive unit tests with 95% code coverage',
        },
      ];

      return {
        success: true,
        data: mockPRs,
      };
    }, config);
  },

  // Step 7: Update ticket with selected PRs
  updateTicketWithPRs: async (
    ticketKey: string,
    selectedPRs: string[],
    allPRs: PullRequest[],
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.05, minDelay: 800, maxDelay: 1500 }
  ): Promise<ApiResponse<JiraTicket>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to update ticket: Invalid ticket key',
          'Failed to update ticket: Permission denied',
          'Failed to update ticket: Content too large',
          'Failed to update ticket: Invalid field format',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      const selectedPRDetails = allPRs.filter(pr => selectedPRs.includes(pr.id));
      const prList = selectedPRDetails.map(pr => `- ${pr.title} (by ${pr.author})`).join('\n');

      return {
        success: true,
        data: {
          id: '12345',
          key: ticketKey,
          summary: `Release ${ticketKey}`,
          description: `Release notes with selected PRs:\n\n${prList}`,
          status: 'Done',
          reporter: 'release-tool@hsbc.com',
          created: new Date().toISOString(),
          updated: new Date().toISOString(),
          url: `https://jira.company.com/browse/${ticketKey}`,
        },
      };
    }, config);
  },

  // Step 8: Generate release notes
  generateReleaseNotes: async (
    releaseData: ReleaseData,
    config: MockApiConfig = { ...defaultConfig, failureRate: 0.02, minDelay: 300, maxDelay: 800 }
  ): Promise<ApiResponse<string>> => {
    return withRetry(async () => {
      await simulateDelay(config);

      if (shouldFail(config)) {
        const errors = [
          'Failed to generate release notes: Template not found',
          'Failed to generate release notes: Invalid data format',
          'Failed to generate release notes: Processing error',
        ];
        throw new Error(errors[Math.floor(Math.random() * errors.length)]);
      }

      const selectedPRs = releaseData.pullRequests?.filter(pr => releaseData.selectedPRs?.includes(pr.id)) || [];

      const releaseNotes = `# Release Notes - ${releaseData.newTag}

## Overview
This release includes ${selectedPRs.length} pull requests with various improvements and bug fixes.

## Changes

${selectedPRs
  .map(pr => {
    const category = pr.title.toLowerCase().includes('fix')
      ? 'Bug Fixes'
      : pr.title.toLowerCase().includes('feature')
        ? 'New Features'
        : pr.title.toLowerCase().includes('doc')
          ? 'Documentation'
          : pr.title.toLowerCase().includes('test')
            ? 'Testing'
            : pr.title.toLowerCase().includes('perf')
              ? 'Performance'
              : 'Other Changes';

    return `### ${category}
- **${pr.title}** - ${pr.description}
  - Author: ${pr.author}
  - PR: [#${pr.id}](${pr.url})`;
  })
  .join('\n\n')}

## Technical Details
- **Previous Tag:** ${releaseData.previousTag}
- **New Tag:** ${releaseData.newTag}
- **Commit Hash:** ${releaseData.commitHash}
- **Jira Ticket:** [${releaseData.jiraTicketId}](${releaseData.jiraTicketUrl})

## Deployment Notes
Please ensure all database migrations are applied before deploying this release.

Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`;

      return {
        success: true,
        data: releaseNotes,
      };
    }, config);
  },
};

// Export configuration for easy customization
export { defaultConfig };
